/*
 * Locking routines that do nothing.
 */

my_lock(fd)
int	fd;
{
	return;
}

my_unlock(fd)
int	fd;
{
	return;
}
