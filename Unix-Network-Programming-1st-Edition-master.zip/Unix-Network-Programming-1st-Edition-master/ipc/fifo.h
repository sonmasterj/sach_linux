#include	<sys/types.h>
#include	<sys/stat.h>
#include	<sys/errno.h>
extern int	errno;

#define	FIFO1	"/tmp/fifo.1"
#define	FIFO2	"/tmp/fifo.2"

#define	PERMS	0666
